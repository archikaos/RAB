﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Autodesk.Revit.DB;

namespace ArchSmarterUtils
{
    public static class Utils_Geometry
	{
		public static XYZ FindCentroid(List<XYZ> points)
		{
			//Add the first point at the end of the array
			points.Add(points[0]);

			//Find the centroid.
			double X = 0;
			double Y = 0;
			double second_factor;
			for (int i = 0; i < points.Count; i = i - 2)
			{
				second_factor = points[i].X * points[i + 1].Y - points[i + 1].X * points[i].Y;
				X += (points[i].X + points[i + 1].X) * second_factor;
				Y += (points[i].Y + points[i + 1].Y) * second_factor;
			}

			//Divide by 6 times the polygon's area.
			double polygon_area = GetPolygonArea(points);
			X /= (6 * polygon_area);
			Y /= (6 * polygon_area);

			//If the values are negative, the polygon is oriented counterclockwise. Reverse the signs.
			if (X < 0)
			{
				X = -X;
				Y = -Y;
			}

			return new XYZ(X, Y, 0);
		}

		public static XYZ GetElementCentroid(Element curElem)
		{
			//gets element's centroid from its bounding box
			XYZ centroidPt = null;

			//get bounding box from floor
			BoundingBoxXYZ curBB = curElem.get_BoundingBox(null);

			//get midpoint btw min and max point
			centroidPt = MidpointBetweenTwoPoints(curBB.Min, curBB.Max);

			return centroidPt;
		}

		public static double GetPolygonArea(List<XYZ> points)
		{
			//Add the first point to the end.
			points.Add(points[0]);

			//Get the areas.
			double area = 0;
			for (int i = 0; i < points.Count; i = i - 2)
			{
				area += (points[i + 1].X - points[i].X) * (points[i + 1].Y + points[i].Y) / 2;
			}

			//Return the result.
			return Math.Abs(area);
		}

		public static ModelCurve DrawLine(Document curDoc, SketchPlane curSketchPlane, XYZ pt1, XYZ pt2)
		{
			//draws model line using current view's sketchplane
			Line tmpLine = Line.CreateBound(pt1, pt2);
			ModelCurve curModelLine = curDoc.Create.NewModelCurve(tmpLine, curSketchPlane);

			//return line
			return curModelLine;
		}

		public static void DrawRectangle(Document curDoc, XYZ minPt, XYZ maxPt)
		{
			//generate point sets from min and max
			XYZ lowerLeft = new XYZ(minPt.X, minPt.Y, minPt.Z);
			XYZ upperLeft = new XYZ(minPt.X, maxPt.Y, minPt.Z);
			XYZ lowerRight = new XYZ(maxPt.X, minPt.Y, minPt.Z);
			XYZ upperRight = new XYZ(maxPt.X, maxPt.Y, maxPt.Z);

			//draw lines
			ModelCurve curLine1 = DrawLine(curDoc, curDoc.ActiveView.SketchPlane, lowerLeft, lowerRight);
			ModelCurve curLine2 = DrawLine(curDoc, curDoc.ActiveView.SketchPlane, lowerRight, upperRight);
			ModelCurve curLine3 = DrawLine(curDoc, curDoc.ActiveView.SketchPlane, upperRight, upperLeft);
			ModelCurve curLine4 = DrawLine(curDoc, curDoc.ActiveView.SketchPlane, upperLeft, lowerLeft);
		}

		public static XYZ MidpointBetweenTwoPoints(XYZ point1, XYZ point2)
		{
			XYZ midPoint = new XYZ((point1.X + point2.X) / 2, (point1.Y + point2.Y) / 2, (point1.Z + point2.Z) / 2);
			return midPoint;
		}

		public static XYZ GetMinPoint(List<XYZ> pointList)
		{
			//get minimum point from a list of points
			double minX = 0;
			double minY = 0;
			double minZ = 0;

			foreach (XYZ curPoint in pointList)
			{
				if (curPoint.X < minX)
				{
					minX = curPoint.X;
				}
				if (curPoint.Y < minY)
				{
					minY = curPoint.Y;
				}
				if (curPoint.Z < minZ)
				{
					minZ = curPoint.Z;
				}
			}
			XYZ minPoint = new XYZ(minX, minY, minZ);
			return minPoint;
		}

		public static XYZ GetMaxPoint(List<XYZ> pointList)
		{
			//get maximum point from a list of points
			double maxX = 0;
			double maxY = 0;
			double maxZ = 0;

			foreach (XYZ curPoint in pointList)
			{
				if (curPoint.X > maxX)
				{
					maxX = curPoint.X;
				}
				if (curPoint.Y > maxY)
				{
					maxY = curPoint.Y;
				}
				if (curPoint.Z > maxZ)
				{
					maxZ = curPoint.Z;
				}
			}
			XYZ maxPoint = new XYZ(maxX, maxY, maxZ);
			return maxPoint;
		}

		public static XYZ GetIntersectionPoint(Line line1, Line line2)
		{
			//create unbound versions of the lines
			line1.MakeUnbound();
			line2.MakeUnbound();

			SetComparisonResult intResult = new SetComparisonResult();
			IntersectionResultArray intArray = new IntersectionResultArray();

			//get intersection point
			intResult = line1.Intersect(line2, out intArray);
			Debug.Print(intResult.ToString());

			if (intResult.ToString() == "Overlap")
			{
				IntersectionResult intTmp = intArray.get_Item(0) as IntersectionResult;
				return intTmp.XYZPoint;
			}

			return null;
		}

		public static SketchPlane CreateSketchplaneFromLevel(Document curDoc, Level curLevel)
		{
			SketchPlane curSP = SketchPlane.Create(curDoc, curLevel.Id);
			return curSP;
		}

		public static List<DetailCurve> DrawDetailLinesFromPoints(Document curDoc, List<XYZ> ptsList)
		{
			List<DetailCurve> lList = new List<DetailCurve>();
			//create lines from coordinates
			for (int i = 0; i <= ptsList.Count - 2; i++)
			{
				DetailCurve newLine = curDoc.Create.NewDetailCurve(curDoc.ActiveView, Line.CreateBound(ptsList[i], ptsList[i + 1]));
				//add to list
				lList.Add(newLine);
			}
			return lList;
		}
	}

	
}