﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.DB.Mechanical;

namespace ArchSmarterUtils
{
    public static class Collectors
    {
        #region Annotation
        public static List<TextNoteType> GetAllTextNoteTypes(Document curDoc)
        {
            List<TextNoteType> returnList = new List<TextNoteType>();

            FilteredElementCollector textStyleCol = new FilteredElementCollector(curDoc);
            textStyleCol.OfClass(typeof(TextNoteType));

            foreach (TextNoteType curType in textStyleCol)
                returnList.Add(curType);

            return returnList;
        }

        public static TextNoteType GetTextNoteTypeByName(Document curDoc, string name)
        {
            List<TextNoteType> textNoteList = GetAllTextNoteTypes(curDoc);

            //loop through text styles and look for match
            foreach (TextNoteType curStyle in textNoteList)
            {
                if (curStyle.Name == name)
                {
                    return curStyle;
                }
            }

            return null;
        }

        public static List<FilledRegionType> GetAllFilledRegionTypes(Document curDoc)
        {
            //get all filled regions
            FilteredElementCollector curCollector = new FilteredElementCollector(curDoc);
            curCollector.OfClass(typeof(FilledRegionType));

            List<FilledRegionType> filledRegionList = new List<FilledRegionType>();

            foreach (FilledRegionType curType in curCollector)
            {
                //add to list
                filledRegionList.Add(curType);
            }

            return filledRegionList;
        }

        //for combo boxes
        public static List<string> GetAllDimTypeNames(Document curDoc)
        {
            //get all dimension types
            FilteredElementCollector dimCollector = new FilteredElementCollector(curDoc);
            dimCollector.OfClass(typeof(DimensionType));

            //loop through dim types and put into list
            List<string> dimTypeList = new List<string>();

            foreach (DimensionType curDimType in dimCollector)
            {
                //add to list
                dimTypeList.Add(curDimType.Name);
            }

            return dimTypeList;
        }
        #endregion
       
        #region Areas and Rooms
        //requires Autodesk.Revit.DB.Architecture
        public static List<Room> GetAllRooms(Document curDoc)
        {
            //get all rooms
            FilteredElementCollector curCollector = new FilteredElementCollector(curDoc);
            curCollector.OfCategory(BuiltInCategory.OST_Rooms);

            List<Room> roomList = new List<Room>();
            foreach (Room curRoom in curCollector.ToElements())
            {
                roomList.Add(curRoom);
            }

            return roomList;
        }

        public static List<ElementId> GetAllRoomsInView(ElementId curLevel, Document m_doc)
        {
            FilteredElementCollector m_col = new FilteredElementCollector(m_doc);
            m_col.OfClass(typeof(SpatialElement)).ToElements();

            //loop through room and find rooms for specified level
            List<ElementId> roomList = new List<ElementId>();
            if (m_col.Count() > 0)
            {
                foreach (SpatialElement e in m_col)
                {
                    Debug.Print(e.GetType().ToString());

                    try
                    {
                        roomList.Add(e.Id);
                    }
                    catch (Exception ex)
                    {
                        Debug.Print(ex.Message);
                    }
                }
            }

            return roomList;
        }

        public static List<Element> GetAllAreas(Document curDoc)
        {
            //get all areas in the current model
            FilteredElementCollector areaCollector = new FilteredElementCollector(curDoc);
            areaCollector.OfCategory(BuiltInCategory.OST_Areas);

            return areaCollector.ToList();
        }
        #endregion

        #region Categories
        public static List<String> GetAllCategories(Document curDoc)
        {
            List<String> catList = new List<String>();

            //loop through categories in current model file
            foreach (Category curCat in curDoc.Settings.Categories)
            {
                //add to list
                catList.Add(curCat.Name);
            }
            //sort list
            catList.Sort();
            return catList;
        }
        #endregion

        #region Elements - Architectural 
        //return list of all windows in the current model
        public static List<FamilyInstance> GetAllWindows(Document curDoc)
        {
            //get all windows
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfCategory(BuiltInCategory.OST_Windows);
            famCollector.OfClass(typeof(FamilyInstance));

            //create list of windows
            List<FamilyInstance> famList = new List<FamilyInstance>();

            foreach (FamilyInstance curFS in famCollector)
            {
                //add to list
                famList.Add(curFS);
            }

            return famList;
        }

        //return list of all doors in the current model
        public static List<FamilyInstance> GetAllDoors(Document curDoc)
        {
            //get all doors
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfClass(typeof(FamilyInstance));
            famCollector.OfCategory(BuiltInCategory.OST_Doors);

            //create list of doors
            List<FamilyInstance> famList = new List<FamilyInstance>();

            foreach (FamilyInstance curFS in famCollector)
            {
                //add to list
                famList.Add(curFS);
            }

            return famList;
        }

        //return list of all floors in the current model
        public static List<Floor> GetAllFloors(Document curDoc)
        {
            //get all floors
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfCategory(BuiltInCategory.OST_Floors);

            //create list of floors
            List<Floor> famList = new List<Floor>();

            foreach (Floor cur in famCollector)
            {
                famList.Add(cur);
            }

            return famList;
        }

        //return list of all ceilings in the current model
        public static List<Ceiling> GetAllCeilings(Document curDoc)
        {
            //get all ceilings
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfCategory(BuiltInCategory.OST_Ceilings);
            famCollector.OfClass(typeof(Ceiling));

            //create list of ceilings
            List<Ceiling> famList = new List<Ceiling>();

            foreach (Ceiling curFS in famCollector)
            {
                //add to list
                famList.Add(curFS);
            }

            return famList;
        }

        //returns list of all casework in the current model
        public static List<FamilyInstance> GetAllCasework(Document curDoc)
        {
            //get all casework
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfClass(typeof(FamilyInstance));
            famCollector.OfCategory(BuiltInCategory.OST_Casework);

            //create list of casework
            List<FamilyInstance> famList = new List<FamilyInstance>();

            foreach (FamilyInstance curFS in famCollector)
            {
                //add to list
                famList.Add(curFS);
            }

            return famList;
        }

        //return list of all roofs in the current model
        public static List<RoofBase> GetAllRoofs(Document curDoc)
        {
            //get all roofs
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfClass(typeof(RoofBase));
            famCollector.OfCategory(BuiltInCategory.OST_Roofs);

            //create list of ceilings
            List<RoofBase> famList = new List<RoofBase>();

            foreach (RoofBase curFS in famCollector)
            {
                //add to list
                famList.Add(curFS);
            }

            return famList;
        }

        //return list of all railings in the current model
        public static List<Railing> GetAllRailings(Document curDoc)
        {
            //get all railings
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfClass(typeof(Railing));

            //create list of elements
            List<Railing> famList = new List<Railing>();

            foreach (Railing curFS in famCollector)
            {
                //add to list
                famList.Add(curFS);
            }

            return famList;
        }

        //return list of all lighting fixtures in the current model
        public static List<FamilyInstance> GetAllLighting(Document curDoc)
        {
            //get all lighting fixtures
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfClass(typeof(FamilyInstance));
            famCollector.OfCategory(BuiltInCategory.OST_LightingFixtures);

            //create list of elements
            List<FamilyInstance> famList = new List<FamilyInstance>();

            foreach (FamilyInstance curFS in famCollector)
            {
                //add to list
                famList.Add(curFS);
            }

            return famList;
        }

        //returns a list of wall face walls in the current model
        public static List<FaceWall> GetAllFaceWalls(Document curDoc)
        {
            List<FaceWall> wallList = new List<FaceWall>();

            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfClass(typeof(FaceWall));

            foreach (FaceWall cur in famCollector)
            {
                //add to list
                wallList.Add(cur);
            }

            return wallList;
        }
        //return list of all floor slab edges in the current model
        public static List<HostedSweep> GetAllSlabEdges(Document curDoc)
        {
            //get all slab edges
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfClass(typeof(HostedSweep));

            //create list of slab edges
            List<HostedSweep> famList = new List<HostedSweep>();

            foreach (HostedSweep cur in famCollector)
            {
                if (cur.GetType() == typeof(SlabEdge))
                {
                    //add to list
                    famList.Add(cur);
                }
            }

            return famList;
        }

        //return list of all ramps in the current model
        public static List<Element> GetAllRamps(Document curDoc)
        {
            //get all ramps
            FilteredElementCollector famCollector = new FilteredElementCollector(curDoc);
            famCollector.OfClass(typeof(Stairs));
            famCollector.OfCategory(BuiltInCategory.OST_Ramps);

            //create list of elements
            List<Element> famList = new List<Element>();

            foreach (Element cur in famCollector)
            {
                //add to list
                famList.Add(cur);
            }

            return famList;
        }
        #endregion

        #region Elements - Mass
        public static List<Element> GetAllMasses(Document curDoc)
        {
            //get all masses in current doc
            FilteredElementCollector massCollector = new FilteredElementCollector(curDoc);
            massCollector.OfCategory(BuiltInCategory.OST_Mass);
            return massCollector.ToList();
        }

        public static List<Element> GetAllMassFloors(Document curDoc)
        {
            //get all massfloors in current doc
            FilteredElementCollector massCollector = new FilteredElementCollector(curDoc);
            massCollector.OfCategory(BuiltInCategory.OST_MassFloor);
            return massCollector.ToList();
        }
        #endregion

        #region Families
        public static List<Family> GetAllFamilies(Document curDoc)
        {
            List<Family> returnList = new List<Family>();

            FilteredElementCollector collector = new FilteredElementCollector(curDoc);
            collector.OfClass(typeof(Family));

            foreach(Family family in collector)
            {
                returnList.Add(family);
            }

            return returnList;
        }

        public static Family GetFamilyByName(Document curDoc, string familyName)
        {
            List<Family> famList = GetAllFamilies(curDoc);

            //loop through family symbols in current project and look for a match
            foreach (Family curFam in famList)
            {
                if (curFam.Name == familyName)
                {
                    return curFam;
                }
            }

            return null;
        }

        public static FamilySymbol GetFamilySymbolByName(Document curDoc, string familyName, string typeName)
        {
            List<Family> famList = GetAllFamilies(curDoc);

            // loop through families in current document and look for match
            foreach (Family f in famList)
            {
                if (f.Name == familyName)
                {
                    // get family symbol from family
                    ISet<ElementId> fsList = f.GetFamilySymbolIds();

                    // loop through family symbol ids and look for match
                    foreach (ElementId fsID in fsList)
                    {
                        FamilySymbol fs = curDoc.GetElement(fsID) as FamilySymbol;

                        if (fs.Name == typeName)
                        {
                            return fs;
                        }
                    }
                }
            }

            return null;
        }

        public static List<FamilySymbol> GetAllFamilySymbols(Document curDoc)
        {
            FilteredElementCollector fCol = new FilteredElementCollector(curDoc);
            fCol.OfClass(typeof(FamilySymbol));

            List<FamilySymbol> fList = new List<FamilySymbol>();

            foreach (FamilySymbol fs in fCol)
            {
                fList.Add(fs);
            }

            return fList;
        }

        //return list of all generic family instances in the current model
        public static List<FamilyInstance> GetAllGenericFamilies(Document curDoc)
        {
            ElementClassFilter famFilter = new ElementClassFilter(typeof(FamilyInstance));
            ElementCategoryFilter typeFilter = new ElementCategoryFilter(BuiltInCategory.OST_GenericModel);
            LogicalAndFilter andFilter = new LogicalAndFilter(famFilter, typeFilter);

            FilteredElementCollector col = new FilteredElementCollector(curDoc);
            col.WherePasses(andFilter);

            List<FamilyInstance> famList = new List<FamilyInstance>();

            foreach (FamilyInstance fam in col)
            {
                famList.Add(fam);
            }

            return famList;
        }

        public static FamilySymbol GetFamilySymbol(Document curDoc, string familyName, string typeName)
        {
            // collect all families
            FilteredElementCollector famColl = new FilteredElementCollector(curDoc);
            famColl.OfClass(typeof(Family));

            // loop through families in current document and look for match
            foreach (Family f in famColl)
            {
                if (f.Name == familyName)
                {
                    // get family symbol from family
                    ISet<ElementId> fsList = f.GetFamilySymbolIds();

                    // loop through family symbol ids and look for match
                    foreach (ElementId fsID in fsList)
                    {
                        FamilySymbol fs = curDoc.GetElement(fsID) as FamilySymbol;

                        if (fs.Name == typeName)
                        {
                            return fs;
                        }
                    }
                }
            }

            return null;
        }
        #endregion

        #region Levels
        public static List<Level> GetAllLevels(Document m_doc)
        {
            FilteredElementCollector m_colLevels = new FilteredElementCollector(m_doc);
            m_colLevels.OfCategory(BuiltInCategory.OST_Levels);

            List<Level> m_levels = new List<Level>();
            foreach (Element x in m_colLevels.ToElements())
            {
                if (x.GetType() == typeof(Level))
                {
                    m_levels.Add((Level)x);
                }
            }

            return m_levels;
            //order list by elevation
            //m_levels = (From l In m_levels Order By l.Elevation).tolist()
        }

        public static Level GetLevelByName(Document curDoc, string levelName)
        {
            FilteredElementCollector levelCollector = new FilteredElementCollector(curDoc);
            levelCollector.OfCategory(BuiltInCategory.OST_Levels);
            levelCollector.OfClass(typeof(Level)).ToElements();

            //loop through levels and find match for levelName argument
            foreach (Level tmpLevel in levelCollector)
            {
                if (tmpLevel.Name == levelName)
                {
                    return tmpLevel;
                }
            }

            return null;
        }
        #endregion

        #region Lines
        public static CategoryNameMap GetAllLineStyles(Document curDoc)
        {
            // get all line styles
            Category c = curDoc.Settings.Categories.get_Item(BuiltInCategory.OST_Lines);
            CategoryNameMap subCats = c.SubCategories;

            return subCats;
        }

        public static List<ModelCurve> GetModelLinesByStyle(Document m_doc, string lineStyle)
        {
            //returns list containing all the models lines of the specific model line style
            List<ModelCurve> lineList = new List<ModelCurve>();
            FilteredElementCollector curCollector = new FilteredElementCollector(m_doc);
            CurveElementFilter curFilter = new CurveElementFilter(CurveElementType.ModelCurve);
            GraphicsStyle curLineStyle;

            //loop through the elements - if element is a model line add to list
            foreach (ModelCurve curCurve in curCollector.WherePasses(curFilter))
            {
                curLineStyle = (GraphicsStyle)curCurve.LineStyle;

                if (curLineStyle.Name.ToString() == lineStyle)
                {
                    //add curve to list
                    lineList.Add(curCurve);
                }
            }

            return lineList;
        }

        public static List<string> GetAllModelLineStyles(Document m_doc)
        {
            //returns list of all model line styles in current model - used by dialog box
            List<string> lineList = new List<string>();
            FilteredElementCollector curCollector = new FilteredElementCollector(m_doc);
            CurveElementFilter curFilter = new CurveElementFilter(CurveElementType.ModelCurve);
            GraphicsStyle curLineStyle;

            //need to filter our arcs and other curved lines
            foreach (ModelCurve curLine in curCollector.WherePasses(curFilter).ToElements())
            {
                curLineStyle = (GraphicsStyle)curLine.LineStyle;
                lineList.Add(curLineStyle.Name.ToString());
            }

            //purge duplicates from list
            for (int i = lineList.Count() - 1; i > 1; i--)
            {
                if (lineList[i] == lineList[i - 1])
                {
                    lineList.RemoveAt(i);
                }
            }

            return lineList;
        }
        #endregion

        #region Links
        public static List<ImportInstance> GetCADLinks(Document curDoc)
        {
            List<ImportInstance> linkList = new List<ImportInstance>();

            //get all CAD links in project
            FilteredElementCollector linkCollector = new FilteredElementCollector(curDoc);
            linkCollector.OfClass(typeof(ImportInstance)).ToElements();

            //loop through collector and put links in list
            foreach (ImportInstance curLink in linkCollector)
            {
                if (curLink.IsLinked == true)
                {
                    linkList.Add(curLink);
                }
            }

            return linkList;
        }

        public static List<GeometryObject> GetLinkedDWGCurves(ImportInstance curLink, Document curDoc)
        {
            //returns list of curves for linked DWG files
            List<GeometryObject> curveList = new List<GeometryObject>();
            Options curOptions = new Options();
            GeometryElement geoElement;
            GeometryInstance geoInstance;
            GeometryElement geoElem2;

            //get geometry from current link
            geoElement = curLink.get_Geometry(curOptions);

            foreach (GeometryObject geoObject in geoElement)
            {
                //convert geoObject to geometry instance
                geoInstance = (GeometryInstance)geoObject;
                geoElem2 = geoInstance.GetInstanceGeometry();

                foreach (GeometryObject curObj in geoElem2)
                {
                    //add object to list
                    curveList.Add(curObj);
                }
            }

            return curveList;
        }

        public static List<RevitLinkInstance> GetAllRVTLinks(Document curDoc)
        {
            List<RevitLinkInstance> linkList = new List<RevitLinkInstance>();

            //get all RVT links in project
            FilteredElementCollector linkCollector = new FilteredElementCollector(curDoc);
            linkCollector.OfCategory(BuiltInCategory.OST_RvtLinks);
            linkCollector.OfClass(typeof(Instance));

            //loop through collector and put links in list
            foreach (RevitLinkInstance curLink in linkCollector)
            {
                linkList.Add(curLink);
            }

            return linkList;
        }

        #endregion

        #region MEP
        public static List<MEPSystemType> GetAllSystemTypes(Document curDoc)
        {
            //returns list of all system types
            FilteredElementCollector curCollector = new FilteredElementCollector(curDoc);
            curCollector.OfClass(typeof(MEPSystem));
            curCollector.WhereElementIsElementType();

            List<MEPSystemType> systemList = new List<MEPSystemType>();

            foreach (MEPSystemType cur in curCollector)
            {
                systemList.Add(cur);
            }

            return systemList;
        }

        public static MEPSystemType GetMEPSystemTypeByName(Document curDoc, string name)
        {
            List<MEPSystemType> systemTypes = GetAllSystemTypes(curDoc);

            foreach(MEPSystemType type in systemTypes)
            {
                if (type.Name == name)
                    return type;
            }

            return null;
        }
        public static List<PipingSystemType> GetAllPipingSystemTypes(Document curDoc)
        {
            FilteredElementCollector curCol = new FilteredElementCollector(curDoc);
            curCol.OfClass(typeof(PipingSystemType));
            curCol.WhereElementIsElementType();

            List<PipingSystemType> sList = new List<PipingSystemType>();

            foreach (PipingSystemType curSys in curCol)
            {
                sList.Add(curSys);
            }

            return sList;
        }

        //get type of system
        public static PipingSystemType GetPipingSystemTypeByName(Document curDoc, string sName)
        {
            //get all systems
            List<PipingSystemType> sList = GetAllPipingSystemTypes(curDoc);

            foreach (PipingSystemType curSys in sList)
            {
                if (curSys.Name == sName)
                {
                    return curSys;
                }
            }

            return null;
        }

        //returns list of all pipe types - used by dialog box
        public static List<string> GetAllPipeTypes(Document curDoc)
        {
            List<string> pList = new List<string>();
            FilteredElementCollector curCol = new FilteredElementCollector(curDoc);
            curCol.OfClass(typeof(PipeType));
            curCol.WhereElementIsElementType();

            foreach (PipeType curPipe in curCol)
            {
                //add pipe type to list
                pList.Add(curPipe.Name);
            }

            return pList;
        }

        //returns wall type object from specified wall type string
        public static PipeType GetPipeType(Document curDoc, string ptName)
        {
            FilteredElementCollector curCol = new FilteredElementCollector(curDoc);
            curCol.OfClass(typeof(PipeType));
            curCol.WhereElementIsElementType();

            foreach (PipeType curPT in curCol)
            {
                if (curPT.Name.ToString() == ptName)
                {
                    return curPT;
                }
            }

            return null;
        }

        #endregion

        #region Schedules
        public static List<ViewSchedule> GetAllSchedules(Document curDoc)
        {
            List<ViewSchedule> schedList = new List<ViewSchedule>();

            FilteredElementCollector curCollector = new FilteredElementCollector(curDoc);
            curCollector.OfClass(typeof(ViewSchedule));

            //loop through views and check if schedule - if so then put into schedule list
            foreach (ViewSchedule curView in curCollector)
            {
                if (curView.ViewType == ViewType.Schedule)
                {
                    schedList.Add((ViewSchedule)curView);
                }
            }

            return schedList;
        }

        public static ViewSchedule GetScheduleByName(Document curDoc, string schedName)
        {
            //collect all schedules in current model
            List<ViewSchedule> viewCollector = GetAllSchedules(curDoc);

            //loop through collection
            foreach (ViewSchedule curView in viewCollector)
            {
                if (curView.Name == schedName)
                {
                    return curView;
                }
            }

            return null;
        }
        #endregion

        #region Scope Boxes
        public static List<Element> GetAllScopeBoxes(Document curDoc)
        {
            // get all scope boxes
            FilteredElementCollector f = new FilteredElementCollector(curDoc);
            f.OfCategory(BuiltInCategory.OST_VolumeOfInterest);

            return f.ToList();
        }

        public static List<string> GetAllScopeBoxNames(Document curDoc)
        {
            // get all scope boxes
            List<Element> sbList = GetAllScopeBoxes(curDoc);

            // create list for scope box names
            List<string> sbNames = new List<string>();

            // loop through list and get scope box names
            foreach (Element curElem in sbList)
            {
                sbNames.Add(curElem.Name);
            }

            return sbNames;
        }

        public static Element GetScopeBoxByName(Document curDoc, string sbName)
        {
            // get all scope boxes
            List<Element> sbList = GetAllScopeBoxes(curDoc);

            // loop through list and look for match
            foreach (Element curElem in sbList)
            {
                if (curElem.Name == sbName)
                {
                    return curElem;
                }
            }

            return null;
        }

        #endregion

        #region Sheets, Titleblocks, and Viewports
        public static List<ViewSheet> GetAllSheets(Document curDoc)
        {
            //get all sheets
            FilteredElementCollector m_colViews = new FilteredElementCollector(curDoc);
            m_colViews.OfCategory(BuiltInCategory.OST_Sheets);

            List<ViewSheet> m_sheets = new List<ViewSheet>();
            foreach (ViewSheet x in m_colViews.ToElements())
            {
                m_sheets.Add(x);
            }

            return m_sheets;
        }

        public static List<ViewSheet> GetAllSheetsByNumber(Document curDoc)
        {
            //get all sheets and update combo boxes
            List<ViewSheet> sList = GetAllSheets(curDoc);

            sList = sList.OrderBy(x => x.SheetNumber).ToList();

            return sList;
        }

        public static ViewSheet GetSheetByName(Document curDoc, string sheetName)
        {
            //get all sheets
            List<ViewSheet> curSheets = GetAllSheets(curDoc);

            //loop through sheets and check sheet name
            foreach (ViewSheet curSheet in curSheets)
            {
                if (curSheet.Name == sheetName)
                {
                    return curSheet;
                }
            }

            return null;
        }

        public static ViewSheet GetSheetByNumber(Document curDoc, string sheetNumber)
        {
            //get all sheets
            List<ViewSheet> curSheets = GetAllSheets(curDoc);

            //loop through sheets and check sheet name
            foreach (ViewSheet curSheet in curSheets)
            {
                if (curSheet.SheetNumber == sheetNumber)
                {
                    return curSheet;
                }
            }

            return null;
        }

        public static List<ViewSheet> GetSheetsByTblockName(Document curDoc, string tblockName)
        {
            List<ViewSheet> selectedSheets = new List<ViewSheet>();

            //get all titleblock instances
            ElementClassFilter tblockfilter = new ElementClassFilter(typeof(FamilyInstance));
            ElementCategoryFilter catFilter = new ElementCategoryFilter(BuiltInCategory.OST_TitleBlocks);
            LogicalAndFilter andFilter = new LogicalAndFilter(tblockfilter, catFilter);

            FilteredElementCollector tblockColl = new FilteredElementCollector(curDoc);
            tblockColl.WherePasses(andFilter);

            foreach (Element curElem in tblockColl)
            {
                FamilyInstance curTblock = (FamilyInstance)curElem;

                if (curTblock.Name == tblockName)
                {
                    //get sheet number parameter value
                    string curSheetNum = Utils.GetParameterValueString(curElem, "Sheet Number");

                    //get sheet by sheet number
                    ViewSheet curSheet = GetSheetByNumber(curDoc, curSheetNum);

                    //add sheet to list
                    selectedSheets.Add(curSheet);
                }
            }

            return selectedSheets;
        }

        public static List<Viewport> GetAllViewports(Document curDoc)
        {
            //get all viewports
            FilteredElementCollector vpCollector = new FilteredElementCollector(curDoc);
            vpCollector.OfCategory(BuiltInCategory.OST_Viewports);

            //output viewports to list
            List<Viewport> vpList = new List<Viewport>();
            foreach (Viewport curVP in vpCollector)
            {
                //add to list
                vpList.Add(curVP);
            }

            return vpList;
        }

        public static List<string> GetAllViewportTypes(Document curDoc)
        {
            List<string> returnList = new List<string>();
            List<Viewport> vpList = GetAllViewports(curDoc);

            foreach (Viewport vp in vpList)
            {
                returnList.Add(vp.Name);
            }

            return returnList;
        }

        public static List<FamilySymbol> GetAllTitleblocks(Document m_doc)
        {
            List<FamilySymbol> returnList = new List<FamilySymbol>();

            FilteredElementCollector collector = new FilteredElementCollector(m_doc);
            collector.WhereElementIsElementType();
            collector.OfCategory(BuiltInCategory.OST_TitleBlocks);

            foreach (FamilySymbol curTB in collector)
            {
                returnList.Add(curTB);
            }

            return returnList;
        }

        public static FamilySymbol GetTitleblockByName(Document curDoc, string tblockname)
        {
            List<FamilySymbol> tblockList = GetAllTitleblocks(curDoc);

            foreach (FamilySymbol curTB in tblockList)
            {
                if (curTB.FamilyName == tblockname)
                {
                    return curTB;
                }
            }

            return null;
        }
        #endregion

        #region Views
        public static List<View> GetAllViews(Document curDoc)
        {
            FilteredElementCollector m_colviews = new FilteredElementCollector(curDoc);
            m_colviews.OfCategory(BuiltInCategory.OST_Views);

            List<View> m_views = new List<View>();
            foreach (View x in m_colviews.ToElements())
            {
                m_views.Add(x);
            }

            return m_views;
        }
        public static List<View> GetAllFloorPlans(Document curDoc)
        {
            List<View> returnList = new List<View>();

            List<View> viewList = GetAllViews(curDoc);

            //loop through views and check for floor plan views
            foreach (View x in viewList)
            {
                if (x.GetType() == typeof(ViewPlan))
                {
                    if (x.IsTemplate == false)
                    {
                        if (x.ViewType == ViewType.FloorPlan)
                        {
                            //add view to list
                            returnList.Add(x);
                        }
                    }
                }
            }

            return returnList;
        }

        public static List<ViewPlan> GetAllViewPlans(Document curDoc)
        {
            List<ViewPlan> returnList = new List<ViewPlan>();

            FilteredElementCollector viewCollector = new FilteredElementCollector(curDoc);
            viewCollector.OfCategory(BuiltInCategory.OST_Views);
            viewCollector.OfClass(typeof(ViewPlan)).ToElements();

            foreach (ViewPlan vp in viewCollector)
            {
                if (vp.IsTemplate == false)
                    returnList.Add(vp);
            }

            return returnList;
        }

        public static List<ViewPlan> GetAllAreaPlans(Document curDoc)
        {
            List<ViewPlan> returnList = new List<ViewPlan>();
            List<ViewPlan> viewList = GetAllViewPlans(curDoc);
            
            foreach (View x in viewList)
            {
                if (x.ViewType == ViewType.AreaPlan)
                {
                    returnList.Add((ViewPlan)x);
                }
            }

            return returnList;
        }

        public static View GetViewByName(Document curDoc, string viewName)
        {
            List<View> viewList = GetAllViews(curDoc);

            //loop through views in the collector
            foreach (View curView in viewList)
            {
                if (curView.Name == viewName)
                {
                    return curView;
                }
            }

            return null;
        }

        public static ViewPlan GetViewPlanByNameAndType(Document curDoc, string viewName, string viewType)
        {
            List<ViewPlan> vpList = GetAllViewPlans(curDoc);

            //loop through collection
            foreach (ViewPlan curView in vpList)
            {
                if (curView.ViewType.ToString() == viewType)
                {
                    if (curView.Name == viewName)
                    {
                        //return specified area plan
                        return curView;
                    }
                }
            }

            return null;
        }

        public static ViewPlan GetAreaPlanByName(string levelName, Document curDoc)
        {
            List<ViewPlan> vpList = GetAllViewPlans(curDoc);

            //loop through collection
            foreach (ViewPlan curView in vpList)
            {
                if (curView.ViewType.ToString() == "AreaPlan")
                {
                    if (curView.Name == levelName)
                    {
                        //return specified area plan
                        return curView;
                    }
                }
            }

            return null;
        }

        public static View GetViewPlanByLevel(Document curDoc, string levelName)
        {
            List<ViewPlan> vpList = GetAllViewPlans(curDoc);

            //loop through views and find match for levelName argument
            foreach (View tmpView in vpList)
            {
                if (tmpView.Name == levelName)
                {
                    return tmpView;
                }
            }

            return null;
        }

        public static List<ViewFamilyType> GetAllViewTypes(Document m_doc)
        {
            //get list of view types
            FilteredElementCollector m_colVT = new FilteredElementCollector(m_doc);
            m_colVT.OfClass(typeof(ViewFamilyType));

            List<ViewFamilyType> m_vt = new List<ViewFamilyType>();
            foreach (ViewFamilyType x in m_colVT.ToElements())
            {
                m_vt.Add(x);
            }

            return m_vt;
        }

        public static ElementId Get3DViewFamilyType(Document curDoc)
        {
            //get list of view types
            List<ViewFamilyType> vTypes = GetAllViewTypes(curDoc);

            foreach (ViewFamilyType x in vTypes)
            {
                if (x.ViewFamily == ViewFamily.ThreeDimensional)
                {
                    return x.Id;
                }
            }

            return null;
        }
        public static List<View3D> GetAll3DViews(Document curDoc)
        {
            //get all views
            List<View> viewList = GetAllViews(curDoc);

            //loop through views and check if 3D
            List<View3D> view3DList = new List<View3D>();

            foreach (View curView in viewList)
            {
                if (curView.GetType() == typeof(View3D))
                {
                    //add to list
                    view3DList.Add((View3D)curView);
                }
            }

            return view3DList;
        }

        public static List<View> GetAllSectionViews(Document m_doc)
        {
            //get all views
            FilteredElementCollector m_colViews = new FilteredElementCollector(m_doc);
            m_colViews.OfCategory(BuiltInCategory.OST_Views);
            m_colViews.OfClass(typeof(ViewSection));

            List<View> m_Views = new List<View>();
            foreach (View x in m_colViews)
            {
                if (x.IsTemplate == false)
                {
                    m_Views.Add(x);
                }
            }

            return m_Views;
        }


        public static View GetViewByNameAndType(Document curDoc, string viewTypeName, string viewName)
        {
            //return the specified view by level
            List<View> viewList = GetAllViews(curDoc);

            //loop through views and find match for viewName argument
            foreach (View tmpView in viewList)
            {
                //get view type name
                string tmpTypeName = tmpView.get_Parameter(BuiltInParameter.VIEW_TYPE).ToString();

                //check if view name and view type name match current view - if so then return
                if (tmpView.Name == viewName & tmpTypeName == viewTypeName)
                {
                    return tmpView;
                }
            }

            return null;
        }

        //get view family type by view type
        public static ViewFamilyType GetViewFamilyType(Document curDoc, ViewFamily vFam)
        {
            List<ViewFamilyType> vftList = GetAllViewTypes(curDoc);

            foreach (ViewFamilyType tmp in vftList)
            {
                if (tmp.GetType() == typeof(ViewType))
                {
                    return tmp;
                }
            }

            return null;
        }

        public static List<View> GetAllDraftingViews(Document curDoc)
        {
            //get all drafting views
            FilteredElementCollector m_colViews = new FilteredElementCollector(curDoc);
            m_colViews.OfCategory(BuiltInCategory.OST_Views);
            m_colViews.OfClass(typeof(ViewDrafting));

            List<View> m_views = new List<View>();
            foreach (View x in m_colViews)
            {
                if (x.IsTemplate == false)
                {
                    m_views.Add(x);
                }
            }

            //sort list
            m_views.Sort();
            return m_views;
        }

        #endregion

        #region Walls and Wall Types
        public static List<Wall> GetAllWalls(Document m_doc)
        {
            //returns list of all walls in current model
            List<Wall> wallList = new List<Wall>();

            FilteredElementCollector curCollector = new FilteredElementCollector(m_doc);
            curCollector.OfCategory(BuiltInCategory.OST_Walls);
            curCollector.OfClass(typeof(Wall));

            foreach (Wall curWall in curCollector)
            {
                //add wall to list
                wallList.Add(curWall);
            }

            return wallList;
        }

        public static List<WallType> GetAllWallTypes(Document curDoc)
        {
            List<WallType> wallList = new List<WallType>();

            FilteredElementCollector curCollector = new FilteredElementCollector(curDoc);
            curCollector.OfClass(typeof(WallType)).ToElements();

            foreach (WallType curWallType in curCollector)
            {
                //add wall type to list
                wallList.Add(curWallType);
            }

            return wallList;
        }

        public static WallType GetWallTypeByName(Document curDoc, string wallTypeName)
        {
            List<WallType> wallTypes = GetAllWallTypes(curDoc);

            foreach (WallType curWallType in wallTypes)
            {
                if (curWallType.Name.ToString() == wallTypeName)
                {
                    //return specified wall type
                    return curWallType;
                }
            }

            return null;
        }

        public static List<WallSweep> GetAllWallSweeps(Document curDoc)
        {
            List<WallSweep> wallList = new List<WallSweep>();

            FilteredElementCollector curCollector = new FilteredElementCollector(curDoc);
            curCollector.OfClass(typeof(WallSweep));

            foreach (WallSweep curWall in curCollector)
            {
                //add wall sweep to list
                wallList.Add(curWall);
            }

            return wallList;
        }
        
        public static List<Wall> GetAllCurtainWall(Document curDoc)
        {
            List<Wall> wallList = GetAllWalls(curDoc);
            List<Wall> cwWallList = new List<Wall>();

            foreach (Wall curWall in wallList)
            {
                if (curWall.CurtainGrid != null)
                {
                    //add wall to list
                    cwWallList.Add(curWall);
                }
            }

            return cwWallList;
        }
        #endregion

        #region View Templates
        public static List<View> GetAllViewTemplates(Document curDoc)
        {
            List<View> returnList = new List<View>();
            List<View> viewList = GetAllViews(curDoc);

            //loop through views and check if is view template
            foreach (View v in viewList)
            {
                if (v.IsTemplate == true)
                {
                    //add view template to list
                    returnList.Add(v);
                }
            }

            return returnList;
        }

        public static List<string> GetAllViewTemplateNames(Document m_doc)
        {
            //returns list of view templates
            List<string> viewTempList = new List<string>();
            List<View> viewList = new List<View>();
            viewList = GetAllViews(m_doc);

            //loop through views and check if is view template
            foreach (View v in viewList)
            {
                if (v.IsTemplate == true)
                {
                    //add view template to list
                    viewTempList.Add(v.Name);
                }
            }

            return viewTempList;
        }

        public static View GetViewTemplateByName(Document curDoc, string viewTemplateName)
        {
            List<View> viewTemplateList = GetAllViewTemplates(curDoc);

            foreach (View v in viewTemplateList)
            {
                if (v.Name == viewTemplateName)
                {
                    return v;
                }
            }

            return null;
        }

        #endregion

        #region Worksets
        public static List<Workset> GetAllWorksets(Document curDoc)
        {
            List<Workset> worksetList = new List<Workset>();

            //get all user created worksets in current file
            FilteredWorksetCollector worksetCollector = new FilteredWorksetCollector(curDoc);
            worksetCollector.OfKind(WorksetKind.UserWorkset);
            worksetCollector.OfKind(WorksetKind.OtherWorkset);

            foreach(Workset curWorkset in worksetCollector)
            {
                worksetList.Add(curWorkset);
            }

            return worksetList;
        }

        public static Workset GetWorksetByName(Document curDoc, string worksetName)
        {
            //get all user created worksets in current file
            List<Workset> worksetList = GetAllWorksets(curDoc);

            //loop through worksets and check if specified workset exists
            foreach (Workset curWorkset in worksetList)
            {
                if (curWorkset.Name == worksetName)
                {
                    return curWorkset;
                }
            }

            return null;
        }
        #endregion

    }
}
