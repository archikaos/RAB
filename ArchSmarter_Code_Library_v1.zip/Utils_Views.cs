﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;

namespace ArchSmarterUtils
{
    internal static class Utils_Views
    {
		public static bool SetActiveView(UIApplication curApp, View curView)
		{
			//set active view
			curApp.ActiveUIDocument.ActiveView = curView;

			return true;
		}

		public static void ZoomToFitCurrentView(UIDocument uidoc, Document doc)
		{
			// zoom to fit active view
			IList<UIView> uiViews = uidoc.GetOpenUIViews();
			foreach (UIView uiv in uiViews)
			{
				if (uiv.ViewId.Equals(doc.ActiveView.Id))
				{
					uiv.ZoomToFit();
				}
			}
		}

		public static bool SetViewTemplate(Document curDoc, View curView, string viewTempName)
		{
			//set view template
			ElementId viewTemplateID = Collectors.GetViewTemplateByName(curDoc, viewTempName).Id;
			if (viewTemplateID == null)
			{
				curView.ViewTemplateId = viewTemplateID;
				return true;
			}
			else
			{
				return false;
			}
		}
		public static View CreateFloorPlanFromLevel(Document curDoc, Level curLevel)
		{
			View newView = null;
			if (Collectors.GetViewPlanByLevel(curDoc, curLevel.Name) == null)
			{
				//get view type
				ViewFamilyType vft = Collectors.GetViewFamilyType(curDoc, ViewFamily.FloorPlan);
				//start transaction
				using (Transaction curTrans = new Transaction(curDoc, "Create Floor lan View"))
				{
					if (curTrans.Start() == TransactionStatus.Started)
					{
						//create view
						newView = ViewPlan.Create(curDoc, vft.Id, curLevel.Id);
					}
					//commit changes
					curTrans.Commit();
				}
			}
			else
			{
				//already exists
				newView = Collectors.GetViewPlanByLevel(curDoc, curLevel.Name);
			}

			return newView;
		}

		public static int DeleteAllViews(Document curDoc)
		{
			int counter = 0;

			//get all views			
			List<View> vList = Collectors.GetAllViews(curDoc);

			//create transaction
			using (Transaction t = new Transaction(curDoc, "Delete All Views"))
			{
				if (t.Start() == TransactionStatus.Started)
				{
					//loop through views - if view is not current then delete
					try
					{
						foreach (View curView in vList)
						{
							if (curDoc.ActiveView.Id.Compare(curView.Id) != 0)
							{
								try
								{
									//delete view
									curDoc.Delete(curView.Id);
									//increment counter
									counter++;
								}
								catch (Exception ex)
								{
									Debug.Print(ex.Message);
								}
							}
						}
					}
					catch (Exception ex)
					{
						Debug.Print(ex.Message);
					}
				}
				//commit changes
				t.Commit();
				t.Dispose();
			}

			return counter;
		}

		public static ViewFamilyType GetViewFamilyTypeFromViewFamily(Document curDoc, ViewFamily vFam)
		{
			List<ViewFamilyType> vftList = Collectors.GetAllViewTypes(curDoc);
			foreach (ViewFamilyType tmp in vftList)
			{
				if (tmp.GetType() == typeof(ViewType))
				{
					return tmp;
				}
			}

			return null;
		}
		public static int DeleteAllSchedules(Document curDoc)
		{
			int counter = 0;

			//get all schedules
			List<ViewSchedule> vList = Collectors.GetAllSchedules(curDoc);

			//create transaction
			using (Transaction t = new Transaction(curDoc, "Delete All Schedules"))
			{
				if (t.Start() == TransactionStatus.Started)
				{
					//loop through schedules - if schedule is not current then delete
					try
					{
						foreach (ViewSchedule curView in vList)
						{
							if (curDoc.ActiveView.Id.Compare(curView.Id) != 0)
							{
								try
								{
									//delete schedule
									curDoc.Delete(curView.Id);
									//increment counter
									counter++;
								}
								catch (Exception ex)
								{
									Debug.Print(ex.Message);
								}
							}
						}
					}
					catch (Exception ex)
					{
						Debug.Print(ex.Message);
					}
				}
				//commit changes
				t.Commit();
				t.Dispose();
			}

			return counter;
		}

		public static List<View> GetAllViewsInUse(Document curDoc)
		{
			List<View> returnList = new List<View>();

			List<View> viewList = Collectors.GetAllViews(curDoc);
			List<ViewSheet> sheetList = Collectors.GetAllSheets(curDoc);

			ElementId sheetID = sheetList.First().Id;

			foreach (Element x in viewList)
			{
				if (x is View)
				{
					View v = x as View;
					if ((!v.IsTemplate) && (!CanViewBeAdded(curDoc, sheetID, v.Id)))
					{
						returnList.Add(v);
					}
				}
			}
			return returnList;
		}

		public static Boolean CanViewBeAdded(Document curDoc, ElementId sheetID, ElementId viewId)
		{
			return Viewport.CanAddViewToSheet(curDoc, sheetID, viewId);
		}

		public static void CenterViewOnSheet(Viewport curVP, View curView, ViewSheet curSheet, Document curDoc)
		{
			XYZ vpCenter;
			Outline vpOutline;
			BoundingBoxUV sheetOutline;
			UV sheetCenter = new UV();

			vpCenter = curVP.GetBoxCenter();
			vpOutline = curVP.GetBoxOutline();

			sheetOutline = curSheet.Outline;
			sheetCenter = (sheetOutline.Min + sheetOutline.Max) * .5;

			XYZ scXYZ = new XYZ(sheetCenter.U, sheetCenter.V, 0);

			curVP.SetBoxCenter(scXYZ);
		}

		public static ElementId GetDraftingViewFamilyTypeID(Document curDoc)
		{
			List<ViewFamilyType> vTypes = Collectors.GetAllViewTypes(curDoc);

			foreach (ViewFamilyType vft in vTypes)
			{
				if (vft.ViewFamily == ViewFamily.Drafting)
				{
					return vft.Id;
				}
			}
			return null;
		}

		public static List<Viewport> GetAllViewportsInView(Document curDoc, ElementId curViewID)
		{
			FilteredElementCollector vpCollector = new FilteredElementCollector(curDoc, curViewID);
			vpCollector.OfCategory(BuiltInCategory.OST_Viewports);

			//output viewports to list
			List<Viewport> vpList = new List<Viewport>();
			foreach (Viewport curVP in vpCollector)
			{
				//add to list
				vpList.Add(curVP);
			}

			return vpList;
		}
	}
}