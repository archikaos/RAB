﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using Autodesk.Revit.UI;
using System.Windows.Media.Imaging;
using System.IO;
using System.Diagnostics;

namespace ArchSmarterUtils
{
    public static class Utils_Addin
    {
		//get full path of .dll assembly
		public static string AssemblyPath()
		{
			return Path.GetDirectoryName(AssemblyFullName());
		}

		//get full name and path of .dll assembly
		public static string AssemblyFullName()
		{
			return Assembly.GetExecutingAssembly().Location;
		}

		public static bool AddPushButton(RibbonPanel panel, string buttonName, string buttonText, string imagePath16, string imagePath32, string dllPath, string dllClass, string toolTip)
		{
			try
			{
				//define push button data
				PushButtonData pbData = new PushButtonData(buttonName, buttonText, dllPath, dllClass);

				//set button images
				if (imagePath16 != "")
				{
					try
					{
						pbData.Image = new BitmapImage(new Uri(imagePath16));
					}
					catch (Exception ex)
					{
						Debug.Print(ex.Message);
						TaskDialog.Show("Error", "Could not find image");
					}
				}
				if (imagePath32 != "")
				{
					try
					{
						pbData.LargeImage = new BitmapImage(new Uri(imagePath32));
					}
					catch (Exception ex)
					{
						Debug.Print(ex.Message);
						TaskDialog.Show("Error", "Could not find image");
					}
				}
				//set tool tip
				pbData.ToolTip = toolTip;

				//add to panel
				PushButton newPB = (PushButton)panel.AddItem(pbData);

				return true;
			}
			catch (Exception ex)
			{
				Debug.Print(ex.Message);
				TaskDialog.Show("Error", "Could not create button - " + ex.Message);
				return false;
			}
		}

		//returns the specified ribbon panel
		public static RibbonPanel GetRibbonPanel(UIControlledApplication app, string panelName)
		{
			RibbonPanel curRibbonPanel = null;

			//loop through panels and look for match
			foreach (RibbonPanel tmpPanel in app.GetRibbonPanels())
			{
				if (tmpPanel.Name == panelName)
				{
					curRibbonPanel = tmpPanel;
				}
			}

			return curRibbonPanel;
		}

		public static BitmapImage BitmapToImageSource(System.Drawing.Bitmap bitmap)
		{
			using (MemoryStream memory = new MemoryStream())
			{
				bitmap.Save(memory, System.Drawing.Imaging.ImageFormat.Png);
				memory.Position = 0;
				BitmapImage bitmapimage = new BitmapImage();
				bitmapimage.BeginInit();
				bitmapimage.StreamSource = memory;
				bitmapimage.CacheOption = BitmapCacheOption.OnLoad;
				bitmapimage.EndInit();

				return bitmapimage;
			}
		}
	}
}
