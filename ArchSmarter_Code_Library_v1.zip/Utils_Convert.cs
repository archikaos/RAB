﻿namespace ArchSmarterUtils
{
    static class Utils_Convert
	{
		public static double ConvertMMtoFT(double mmDim)
		{
			//convert millimeters to feet
			double convert = (mmDim / 25.4) / 12;

			return convert;
		}

		public static double ConvertCMtoFT(double cmDim)
		{
			//convert centimeters to feet
			double convert = (cmDim / 2.54) / 12;

			return convert;
		}

		public static double ConvertMtoFT(double mDim)
		{
			//convert meters to feet
			return mDim * 3.28084;
		}
	}
}